# Regras específicas do Drago Mapping entram aqui conforme necessário
# (ex.: manter classes de modelo de perfil para serialização JSON).
