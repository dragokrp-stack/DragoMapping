package com.dragomapping.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.dragomapping.app.navigation.DragoDestination
import com.dragomapping.app.ui.screens.*
import com.dragomapping.app.ui.theme.DragoMappingTheme
import com.dragomapping.app.ui.theme.DragoThemeMode

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var themeMode by remember { mutableStateOf(DragoThemeMode.DARK) }

            DragoMappingTheme(themeMode = themeMode) {
                DragoMappingApp(
                    themeMode = themeMode,
                    onThemeChange = { themeMode = it }
                )
            }
        }
    }
}

@Composable
fun DragoMappingApp(
    themeMode: DragoThemeMode,
    onThemeChange: (DragoThemeMode) -> Unit
) {
    val navController = rememberNavController()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = backStackEntry?.destination?.route

                DragoDestination.bottomBarItems.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(destination.icon, contentDescription = null) },
                        label = { Text(stringResource(destination.labelRes)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = DragoDestination.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(DragoDestination.Dashboard.route) { DashboardScreen() }
            composable(DragoDestination.Profiles.route) { ProfilesScreen() }
            composable(DragoDestination.Keyboard.route) { KeyboardScreen() }
            composable(DragoDestination.Mouse.route) { MouseScreen() }
            composable(DragoDestination.Settings.route) {
                SettingsScreen(currentTheme = themeMode, onThemeChange = onThemeChange)
            }
        }
    }
}
