package com.dragomapping.app

import android.app.Application

/**
 * Application principal do Drago Mapping.
 * Mantido enxuto de propósito: inicialização pesada (carregar perfis,
 * abrir conexão com dispositivos, etc.) deve ser feita de forma lazy/async
 * nas telas que realmente precisam, para garantir inicialização rápida do app.
 */
class DragoMappingApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // TODO: inicializar ProfileRepository (DataStore) de forma assíncrona
        // TODO: inicializar CrashLogger / sistema de logs detalhados
    }
}
