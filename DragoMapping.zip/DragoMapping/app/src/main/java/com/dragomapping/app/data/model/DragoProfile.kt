package com.dragomapping.app.data.model

import kotlinx.serialization.Serializable

/**
 * Formato nativo de perfil do Drago Mapping (extensão de arquivo: .dmap).
 * É um JSON simples de propósito — fácil de versionar, de depurar (dá pra
 * abrir num editor de texto) e de estender sem quebrar perfis antigos.
 */
@Serializable
data class DragoProfile(
    val schemaVersion: Int = 1,
    val id: String,
    val name: String,
    val targetPackageName: String? = null, // para troca automática de perfil
    val passwordProtected: Boolean = false,
    val passwordHash: String? = null,
    val keyboardMappings: List<KeyMapping> = emptyList(),
    val mouseSettings: MouseSettings = MouseSettings(),
    val controllerSettings: ControllerSettings = ControllerSettings(),
    val macros: List<Macro> = emptyList()
)

@Serializable
data class KeyMapping(
    val sourceKeyCode: Int,
    val targetAction: MappedAction,
    val deviceDescriptor: String? = null // permite perfis diferentes por teclado físico
)

@Serializable
sealed class MappedAction {
    @Serializable
    data class SingleKey(val keyCode: Int) : MappedAction()

    @Serializable
    data class Combination(val keyCodes: List<Int>) : MappedAction()

    @Serializable
    data class RunMacro(val macroId: String) : MappedAction()

    @Serializable
    data class Toggle(val keyCode: Int) : MappedAction()

    @Serializable
    data object None : MappedAction()
}

@Serializable
data class Macro(
    val id: String,
    val name: String,
    val steps: List<MacroStep>,
    val loop: Boolean = false
)

@Serializable
data class MacroStep(
    val keyCode: Int,
    val pressDurationMs: Long = 40,
    val delayAfterMs: Long = 20
)

@Serializable
data class MouseSettings(
    val virtualDpi: Int = 800,
    val sensitivityX: Float = 1.0f,
    val sensitivityY: Float = 1.0f,
    val acceleration: Float = 0f,
    val responseCurve: ResponseCurve = ResponseCurve.LINEAR,
    val invertX: Boolean = false,
    val invertY: Boolean = false,
    val scrollSpeed: Float = 1.0f,
    val pointerSpeed: Float = 1.0f,
    val clickSpeedMs: Long = 0,
    val buttonMappings: Map<Int, MappedAction> = emptyMap()
)

@Serializable
enum class ResponseCurve { LINEAR, EXPONENTIAL, LOGARITHMIC, CUSTOM }

@Serializable
data class ControllerSettings(
    val deadzoneLeftStick: Float = 0.1f,
    val deadzoneRightStick: Float = 0.1f,
    val stickCurve: ResponseCurve = ResponseCurve.LINEAR,
    val triggerSensitivityLeft: Float = 1.0f,
    val triggerSensitivityRight: Float = 1.0f,
    val vibrationIntensity: Float = 1.0f,
    val buttonMappings: Map<Int, MappedAction> = emptyMap(),
    val emulateLayout: ControllerLayout? = null
)

@Serializable
enum class ControllerLayout { XBOX, DUALSHOCK, SWITCH_PRO, GENERIC }
