package com.dragomapping.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.dragomapping.app.R
import com.dragomapping.app.data.importexport.ImportOutcome
import com.dragomapping.app.data.importexport.ProfileImportExportManager
import com.dragomapping.app.data.model.DragoProfile
import com.dragomapping.app.data.repository.ProfileRepository
import kotlinx.coroutines.launch

@Composable
fun ProfilesScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val repository = remember { ProfileRepository(context) }
    val importExportManager = remember { ProfileImportExportManager(context, repository) }
    val profiles by repository.profiles.collectAsState()

    var showNewProfileDialog by remember { mutableStateOf(false) }
    var pendingRewasdImport by remember { mutableStateOf<DragoProfile?>(null) }
    var pendingExportProfile by remember { mutableStateOf<DragoProfile?>(null) }

    LaunchedEffect(Unit) { repository.loadAll() }

    // ---- Selecionar arquivo para IMPORTAR (.dmap nativo ou reWASD) ----
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            when (val outcome = importExportManager.importFromUri(uri)) {
                is ImportOutcome.NativeSuccess -> {
                    repository.save(outcome.profile)
                    snackbarHostState.showSnackbar("Perfil \"${outcome.profile.name}\" importado")
                }
                is ImportOutcome.ReWasdSuccess -> {
                    // Perfil do reWASD: mostra relatório antes de salvar, já que a
                    // conversão é best-effort e pode ter deixado campos de fora.
                    pendingRewasdImport = outcome.report.profile
                }
                is ImportOutcome.Failure -> {
                    snackbarHostState.showSnackbar(outcome.reason)
                }
            }
        }
    }

    // ---- Selecionar destino para EXPORTAR ----
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        val profile = pendingExportProfile
        if (uri != null && profile != null) {
            scope.launch {
                val ok = importExportManager.exportToUri(profile, uri)
                snackbarHostState.showSnackbar(
                    if (ok) "Perfil exportado" else "Falha ao exportar perfil"
                )
            }
        }
        pendingExportProfile = null
    }

    Scaffold(
        modifier = modifier,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End) {
                SmallFloatingActionButton(
                    onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) }
                ) { Icon(Icons.Filled.FileDownload, contentDescription = stringResource(R.string.profiles_import)) }
                Spacer(Modifier.height(10.dp))
                ExtendedFloatingActionButton(
                    onClick = { showNewProfileDialog = true },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text(stringResource(R.string.profiles_new)) }
                )
            }
        }
    ) { padding ->
        if (profiles.isEmpty()) {
            EmptyProfilesState(Modifier.padding(padding).fillMaxSize())
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(profiles, key = { it.id }) { profile ->
                    ProfileRow(
                        profile = profile,
                        onExport = {
                            pendingExportProfile = profile
                            exportLauncher.launch("${profile.name}.dmap")
                        },
                        onDelete = { scope.launch { repository.delete(profile.id) } }
                    )
                }
            }
        }
    }

    if (showNewProfileDialog) {
        NewProfileDialog(
            onDismiss = { showNewProfileDialog = false },
            onConfirm = { name ->
                scope.launch { repository.save(repository.newEmptyProfile(name)) }
                showNewProfileDialog = false
            }
        )
    }

    pendingRewasdImport?.let { profile ->
        RewasdImportDialog(
            profile = profile,
            onConfirm = {
                scope.launch {
                    repository.save(profile)
                    snackbarHostState.showSnackbar("Perfil convertido do reWASD e salvo")
                }
                pendingRewasdImport = null
            },
            onDismiss = { pendingRewasdImport = null }
        )
    }
}

@Composable
private fun NewProfileDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.profiles_new)) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(stringResource(R.string.profiles_name_label)) },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text) }) {
                Text(stringResource(R.string.action_create))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}

@Composable
private fun RewasdImportDialog(profile: DragoProfile, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.rewasd_import_title)) },
        text = { Text(stringResource(R.string.rewasd_import_message, profile.name)) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(stringResource(R.string.action_save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}

@Composable
private fun EmptyProfilesState(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Gamepad, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.profiles_empty_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.profiles_empty_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ProfileRow(profile: DragoProfile, onExport: () -> Unit, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Gamepad, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(profile.name, style = MaterialTheme.typography.titleMedium)
                if (profile.passwordProtected) {
                    Text(
                        stringResource(R.string.profiles_protected),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            IconButton(onClick = onExport) { Icon(Icons.Filled.FileUpload, contentDescription = stringResource(R.string.profiles_export)) }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.action_delete)) }
        }
    }
}
