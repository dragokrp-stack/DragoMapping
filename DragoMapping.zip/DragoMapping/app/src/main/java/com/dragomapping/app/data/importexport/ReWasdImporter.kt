package com.dragomapping.app.data.importexport

import com.dragomapping.app.data.model.*
import kotlinx.serialization.json.*
import java.util.UUID

/**
 * Resultado de uma tentativa de importação: o perfil convertido (se algo
 * pôde ser aproveitado) + um relatório legível do que funcionou e do que não.
 * Isso é importante para não passar uma falsa sensação de "importação 100%
 * fiel" quando na prática é uma conversão best-effort.
 */
data class ImportReport(
    val profile: DragoProfile?,
    val convertedFields: List<String>,
    val skippedFields: List<String>,
    val warnings: List<String>
)

/**
 * IMPORTANTE — leia antes de usar/editar este arquivo:
 * O reWASD é um software comercial e o formato de arquivo dele (.rewasd)
 * NÃO é uma especificação pública documentada pela empresa. Este conversor
 * não faz engenharia reversa do binário/algoritmo deles — ele apenas lê o
 * arquivo como JSON genérico (muitos exports de configuração de terceiros
 * usam JSON) e tenta reconhecer nomes de campo e de botões que são padrão
 * da indústria (A/B/X/Y, LB/RB, LT/RT, DPI, sensibilidade etc.), remapeando
 * o que reconhece para o formato do Drago Mapping.
 *
 * Resultado esperado: campos comuns e simples tendem a converter bem;
 * recursos avançados/proprietários do reWASD (curvas customizadas deles,
 * scripts internos, etc.) NÃO serão convertidos — ficam listados em
 * `skippedFields` para o usuário saber exatamente o que precisa recriar
 * manualmente.
 */
object ReWasdImporter {

    private val knownButtonNames = mapOf(
        "A" to 96, "B" to 97, "X" to 99, "Y" to 100,          // KeyEvent.KEYCODE_BUTTON_*
        "LB" to 102, "RB" to 103, "LT" to 104, "RT" to 105,
        "LS" to 106, "RS" to 107,
        "DPAD_UP" to 19, "DPAD_DOWN" to 20, "DPAD_LEFT" to 21, "DPAD_RIGHT" to 22
    )

    fun import(rawText: String): ImportReport {
        val converted = mutableListOf<String>()
        val skipped = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        val root = try {
            Json.parseToJsonElement(rawText).jsonObject
        } catch (e: Exception) {
            return ImportReport(
                profile = null,
                convertedFields = emptyList(),
                skippedFields = emptyList(),
                warnings = listOf(
                    "Não foi possível interpretar o arquivo como JSON. " +
                        "Se este for um export binário do reWASD, esta versão do " +
                        "conversor ainda não suporta esse formato."
                )
            )
        }

        val name = root["name"]?.jsonPrimitive?.contentOrNull
            ?: root["profileName"]?.jsonPrimitive?.contentOrNull
            ?: "Perfil importado"
        if (root.containsKey("name") || root.containsKey("profileName")) converted += "nome do perfil"

        // ---- Botões de controle ----
        val buttonMappings = mutableMapOf<Int, MappedAction>()
        val buttonsNode = root["buttons"]?.jsonObject ?: root["mappings"]?.jsonObject
        buttonsNode?.forEach { (buttonName, targetNode) ->
            val sourceCode = knownButtonNames[buttonName.uppercase()]
            val targetCode = targetNode.jsonPrimitive.contentOrNull
                ?.let { knownButtonNames[it.uppercase()] }
            if (sourceCode != null && targetCode != null) {
                buttonMappings[sourceCode] = MappedAction.SingleKey(targetCode)
                converted += "botão $buttonName"
            } else {
                skipped += "botão $buttonName (formato não reconhecido)"
            }
        }
        if (buttonsNode == null) warnings += "Nenhuma seção de botões reconhecida no arquivo."

        // ---- Sensibilidade / DPI / deadzone (nomes comuns entre softwares do gênero) ----
        val dpi = root["dpi"]?.jsonPrimitive?.intOrNull
            ?: root["virtualDpi"]?.jsonPrimitive?.intOrNull
        if (dpi != null) converted += "DPI virtual"

        val sensitivity = root["sensitivity"]?.jsonPrimitive?.floatOrNull ?: 1.0f
        if (root.containsKey("sensitivity")) converted += "sensibilidade"

        val deadzone = root["deadzone"]?.jsonPrimitive?.floatOrNull
            ?: root["leftStickDeadzone"]?.jsonPrimitive?.floatOrNull
        if (deadzone != null) converted += "deadzone do analógico"

        // ---- Campos conhecidamente proprietários/avançados do reWASD que não convertem ----
        listOf("scripts", "shiftLayers", "advancedCurve", "chords", "macrosNative").forEach { key ->
            if (root.containsKey(key)) {
                skipped += "$key (recurso avançado específico do reWASD, sem equivalente direto)"
            }
        }

        val profile = DragoProfile(
            id = UUID.randomUUID().toString(),
            name = name,
            controllerSettings = ControllerSettings(
                deadzoneLeftStick = deadzone ?: 0.1f,
                buttonMappings = buttonMappings
            ),
            mouseSettings = MouseSettings(
                virtualDpi = dpi ?: 800,
                sensitivityX = sensitivity,
                sensitivityY = sensitivity
            )
        )

        return ImportReport(profile, converted.distinct(), skipped.distinct(), warnings)
    }
}
