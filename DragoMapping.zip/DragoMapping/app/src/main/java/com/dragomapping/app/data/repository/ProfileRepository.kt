package com.dragomapping.app.data.repository

import android.content.Context
import com.dragomapping.app.data.model.DragoProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

/**
 * Fonte única de verdade dos perfis. Guarda cada perfil como um arquivo
 * .dmap (JSON) dentro do armazenamento privado do app
 * (/data/data/com.dragomapping.app/files/profiles/), o que já cobre o
 * requisito de "perfis ilimitados" sem precisar de banco de dados.
 */
class ProfileRepository(private val context: Context) {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true // não quebra ao ler perfis de versões futuras
        encodeDefaults = true
    }

    private val profilesDir: File
        get() = File(context.filesDir, "profiles").apply { mkdirs() }

    private val _profiles = MutableStateFlow<List<DragoProfile>>(emptyList())
    val profiles: StateFlow<List<DragoProfile>> = _profiles.asStateFlow()

    suspend fun loadAll() = withContext(Dispatchers.IO) {
        val loaded = profilesDir.listFiles { f -> f.extension == "dmap" }
            ?.mapNotNull { file ->
                runCatching { json.decodeFromString<DragoProfile>(file.readText()) }.getOrNull()
            }
            ?.sortedBy { it.name }
            ?: emptyList()
        _profiles.value = loaded
    }

    suspend fun save(profile: DragoProfile) = withContext(Dispatchers.IO) {
        val file = File(profilesDir, "${profile.id}.dmap")
        file.writeText(json.encodeToString(profile))
        loadAll()
    }

    suspend fun delete(profileId: String) = withContext(Dispatchers.IO) {
        File(profilesDir, "$profileId.dmap").delete()
        loadAll()
    }

    fun newEmptyProfile(name: String): DragoProfile =
        DragoProfile(id = UUID.randomUUID().toString(), name = name)

    /** Serializa um perfil para texto — usado pela exportação (arquivo ou QR Code). */
    fun serialize(profile: DragoProfile): String = json.encodeToString(profile)

    /** Desserializa um perfil no formato nativo .dmap. */
    fun deserializeNative(text: String): Result<DragoProfile> =
        runCatching { json.decodeFromString(text) }
}
