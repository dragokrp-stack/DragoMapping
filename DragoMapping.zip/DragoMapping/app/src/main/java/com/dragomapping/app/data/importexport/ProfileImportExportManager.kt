package com.dragomapping.app.data.importexport

import android.content.Context
import android.net.Uri
import com.dragomapping.app.data.model.DragoProfile
import com.dragomapping.app.data.repository.ProfileRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class ImportOutcome {
    data class NativeSuccess(val profile: DragoProfile) : ImportOutcome()
    data class ReWasdSuccess(val report: ImportReport) : ImportOutcome()
    data class Failure(val reason: String) : ImportOutcome()
}

/**
 * Ponto único usado pela UI para importar/exportar. Detecta automaticamente
 * se o arquivo é um .dmap nativo ou algo no formato reWASD e escolhe o
 * caminho de conversão correto — cumprindo o requisito de "converter
 * automaticamente as configurações compatíveis" sem o usuário precisar
 * escolher manualmente o tipo de arquivo.
 */
class ProfileImportExportManager(
    private val context: Context,
    private val repository: ProfileRepository
) {
    suspend fun importFromUri(uri: Uri): ImportOutcome = withContext(Dispatchers.IO) {
        val text = try {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        } catch (e: Exception) {
            null
        } ?: return@withContext ImportOutcome.Failure("Não foi possível ler o arquivo selecionado.")

        // Tenta primeiro como formato nativo do Drago Mapping.
        repository.deserializeNative(text).getOrNull()?.let { profile ->
            return@withContext ImportOutcome.NativeSuccess(profile)
        }

        // Se não for nativo, tenta a conversão best-effort do formato reWASD.
        val report = ReWasdImporter.import(text)
        if (report.profile != null) {
            ImportOutcome.ReWasdSuccess(report)
        } else {
            ImportOutcome.Failure(
                report.warnings.firstOrNull()
                    ?: "O arquivo não pôde ser reconhecido como um perfil válido."
            )
        }
    }

    suspend fun exportToUri(profile: DragoProfile, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(repository.serialize(profile).toByteArray())
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
