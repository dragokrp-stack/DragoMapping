package com.dragomapping.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.dragomapping.app.R

/**
 * Cada item da navegação principal (usada tanto na barra inferior em
 * celular/tablet quanto no menu lateral no modo Android TV / DeX).
 */
sealed class DragoDestination(val route: String, val labelRes: Int, val icon: ImageVector) {
    data object Dashboard : DragoDestination("dashboard", R.string.nav_dashboard, Icons.Filled.Dashboard)
    data object Profiles : DragoDestination("profiles", R.string.nav_profiles, Icons.Filled.Gamepad)
    data object Keyboard : DragoDestination("keyboard", R.string.nav_keyboard, Icons.Filled.Keyboard)
    data object Mouse : DragoDestination("mouse", R.string.nav_mouse, Icons.Filled.Mouse)
    data object Settings : DragoDestination("settings", R.string.nav_settings, Icons.Filled.Settings)

    companion object {
        val bottomBarItems = listOf(Dashboard, Profiles, Keyboard, Mouse, Settings)
    }
}
