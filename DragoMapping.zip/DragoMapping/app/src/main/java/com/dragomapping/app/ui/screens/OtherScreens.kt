package com.dragomapping.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.dragomapping.app.R
import com.dragomapping.app.ui.theme.DragoThemeMode

@Composable
fun KeyboardScreen(modifier: Modifier = Modifier) {
    PlaceholderScreen(
        modifier = modifier,
        title = stringResource(R.string.nav_keyboard),
        message = stringResource(R.string.keyboard_placeholder)
    )
}

@Composable
fun MouseScreen(modifier: Modifier = Modifier) {
    PlaceholderScreen(
        modifier = modifier,
        title = stringResource(R.string.nav_mouse),
        message = stringResource(R.string.mouse_placeholder)
    )
}

@Composable
fun SettingsScreen(
    currentTheme: DragoThemeMode,
    onThemeChange: (DragoThemeMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.nav_settings), style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeChip(stringResource(R.string.theme_dark), currentTheme == DragoThemeMode.DARK) {
                onThemeChange(DragoThemeMode.DARK)
            }
            ThemeChip(stringResource(R.string.theme_light), currentTheme == DragoThemeMode.LIGHT) {
                onThemeChange(DragoThemeMode.LIGHT)
            }
            ThemeChip(stringResource(R.string.theme_amoled), currentTheme == DragoThemeMode.AMOLED) {
                onThemeChange(DragoThemeMode.AMOLED)
            }
        }
    }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun PlaceholderScreen(title: String, message: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
