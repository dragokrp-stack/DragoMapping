package com.dragomapping.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** As três variações de tema pedidas: escuro, claro e AMOLED (preto puro). */
enum class DragoThemeMode { DARK, LIGHT, AMOLED }

private val DarkScheme = darkColorScheme(
    primary = DragoPurple,
    onPrimary = Color.White,
    primaryContainer = DragoPurpleDeep,
    secondary = DragoMagentaAccent,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnBackground,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceMuted,
    error = StatusOffline
)

private val AmoledScheme = darkColorScheme(
    primary = DragoPurple,
    onPrimary = Color.White,
    primaryContainer = DragoPurpleDeep,
    secondary = DragoMagentaAccent,
    background = AmoledBackground,
    onBackground = DarkOnBackground,
    surface = AmoledSurface,
    onSurface = DarkOnBackground,
    surfaceVariant = AmoledSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceMuted,
    error = StatusOffline
)

private val LightScheme = lightColorScheme(
    primary = DragoPurpleDeep,
    onPrimary = Color.White,
    primaryContainer = DragoPurpleGlow,
    secondary = DragoMagentaAccent,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnBackground,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceMuted,
    error = StatusOffline
)

@Composable
fun DragoMappingTheme(
    themeMode: DragoThemeMode = if (isSystemInDarkTheme()) DragoThemeMode.DARK else DragoThemeMode.LIGHT,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        DragoThemeMode.DARK -> DarkScheme
        DragoThemeMode.AMOLED -> AmoledScheme
        DragoThemeMode.LIGHT -> LightScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DragoTypography,
        content = content
    )
}
