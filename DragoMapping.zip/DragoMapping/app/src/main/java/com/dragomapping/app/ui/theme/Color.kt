package com.dragomapping.app.ui.theme

import androidx.compose.ui.graphics.Color

// ===== Cor de assinatura da marca =====
val DragoPurple = Color(0xFF9D4EFF)       // roxo principal (ações, destaques)
val DragoPurpleDeep = Color(0xFF6A2FBF)   // roxo profundo (pressed/variant)
val DragoPurpleGlow = Color(0xFFC79BFF)   // roxo claro (glow/hover)
val DragoMagentaAccent = Color(0xFFFF4ECD) // acento secundário (alertas de status, RGB vibe)

// ===== Tema ESCURO (padrão) =====
val DarkBackground = Color(0xFF121016)
val DarkSurface = Color(0xFF1B1820)
val DarkSurfaceVariant = Color(0xFF262230)
val DarkOnBackground = Color(0xFFEDEAF5)
val DarkOnSurfaceMuted = Color(0xFFA9A3B8)

// ===== Tema AMOLED (preto puro, para economia de bateria em telas OLED) =====
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF0A090D)
val AmoledSurfaceVariant = Color(0xFF15121A)

// ===== Tema CLARO =====
val LightBackground = Color(0xFFF7F5FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDE7F6)
val LightOnBackground = Color(0xFF1B1820)
val LightOnSurfaceMuted = Color(0xFF5B5568)

// ===== Semânticas de status (usadas em diagnóstico, latência, conexão) =====
val StatusOnline = Color(0xFF3DDC84)
val StatusWarning = Color(0xFFFFB74D)
val StatusOffline = Color(0xFFFF5252)
